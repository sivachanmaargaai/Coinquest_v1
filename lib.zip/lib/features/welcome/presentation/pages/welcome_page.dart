import 'package:flutter/material.dart';
import '../../../../core/constants/app_colors.dart';
import '../../../../core/theme/app_text_styles.dart';

/// TEMPORARY placeholder — Screen 5 (Welcome) will be built properly next.
/// This just confirms Splash -> Onboarding -> here navigation works.
class WelcomePage extends StatelessWidget {
  const WelcomePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        width: double.infinity,
        height: double.infinity,
        decoration: const BoxDecoration(gradient: AppColors.backgroundGradient),
        child: Center(
          child: Text(
            'Welcome Screen\n(coming next)',
            textAlign: TextAlign.center,
            style: AppTextStyles.h2,
          ),
        ),
      ),
    );
  }
}
